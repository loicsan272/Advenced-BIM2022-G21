import ifcopenshell
import os.path
import time
import pandas as pd
import numpy
import openpyxl
################ define ifc model #################################################
model_url = r"C:\Users\loics\Weight and Density Values of Walls and Foundations\model\duplex.ifc"
start_time = time.time()
if (os.path.exists(model_url)):
    file = ifcopenshell.open(model_url)
    print("\tLoad    : {:.2f}s".format(float(time.time() - start_time)))
                
else:
    print("\nERROR: please check your model folder : " +model_url+" does not exist")
##################### create the excel file ###############################
wb = openpyxl.load_workbook(r"C:\Users\loics\Weight and Density Values of Walls and Foundations\input\Inputs.xlsx")
S = wb["Sheet1"]
S.cell(1,1).value = "ID"
S.cell(1,2).value = "Steel ratio"
S.cell(1,3).value = "concrete density"
i=1
for w in file.by_type('IfcWall'):
     if "Foundation" in w.ObjectType:
        i+=1
        S.cell(i,1).value = w.Name[11:21]+w.Name[40:]
for w in file.by_type('IfcWall'):
    if ("Exterior" in w.ObjectType):
        i+=1
        S.cell(i,1).value = w.Name[11:19]+w.Name[36:]
    if ("Party" in w.ObjectType):
        i+=1
        S.cell(i,1).value =w.Name[11:21]+w.Name[58:]
############################# make it readible ##############################
S.column_dimensions['A'].width = 16
S.column_dimensions['C'].width = 15
wb.save(r"C:\Users\loics\Weight and Density Values of Walls and Foundations\input\Inputs.xlsx")