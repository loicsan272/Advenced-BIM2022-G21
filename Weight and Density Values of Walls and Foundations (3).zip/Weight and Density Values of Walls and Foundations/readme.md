This tool is made to calculate the weight and density of the reinforced
concrete walls and foundations. Here is a step by step guide to use this
tool:

-use the input file.py program to generate an excel file with all the
structural walls named Inputs.xlsx

-in this file set the steel\_ratio and the concrete density you want for
every walls it is important that 0\<=steel\_ratio\<=1

-launch the main.py program, this program generate an output file with
all the informations about the elements, and the global structure named
StructuralWallsWeight.xlsx

I wanted to add the informations that we find in the input file directly
in the IFC model, but i wasn't able to modify IFC files. Also, as this
tool is only about reinforced concrete, material of the walls should be
changed
