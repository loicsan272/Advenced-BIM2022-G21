import ifcopenshell
import os.path
import time
import pandas as pd
import numpy
import openpyxl
################ define ifc model #####################################################
model_url = r"C:\Users\loics\Weight and Density Values of Walls and Foundations\model\duplex.ifc"
start_time = time.time()
if (os.path.exists(model_url)):
    file = ifcopenshell.open(model_url)
    print("\tLoad    : {:.2f}s".format(float(time.time() - start_time)))
                
else:
    print("\nERROR: please check your model folder : " +model_url+" does not exist")

S_ratio = 0.2
S_D =7800
C_D = 2500
#######################################################################################
NAME=[]
S_V=[]
S_W=[]
C_V=[]
C_W=[]
W=[]
D=[]
F_V = 0
W_V = 0
############################# open the inputs file ####################################
ip = openpyxl.load_workbook(r"C:\Users\loics\Weight and Density Values of Walls and Foundations\input\Inputs.xlsx")
inputs = ip["Sheet1"]
############################# foundations #############################################
for w in file.by_type('IfcWall'):
     if "Foundation" in w.ObjectType:
        #find steel ratio and concrete density of the element
        cont = True
        i=1
        while cont:
            i+=1
            if inputs.cell(i,1).value == w.Name[11:21]+w.Name[40:]:
                S_ratio = inputs.cell(i,2).value
                C_D = inputs.cell(i,3).value
                cont = False
        if  (S_ratio < 0)|(S_ratio>1)|(C_D<0):
            print("\nERROR:  : input out of range")
        for definition in w.IsDefinedBy:    
            ## To support IFC2X3, we need to filter our results.
            if definition.is_a('IfcRelDefinesByProperties'):
                property_set = definition.RelatingPropertyDefinition
                if property_set.Name == "PSet_Revit_Dimensions":
                    for property in property_set.HasProperties:
                        if property.Name=="Volume":
                            V = float(str(property[2])[17:len(str(property[2]))-1])
        F_V=F_V+V
        NAME.append(w.Name[11:21]+w.Name[40:])
        S_V.append(V*S_ratio)
        S_W.append(V*S_ratio*S_D)
        C_V.append(V*(1-S_ratio))
        C_W.append(V*(1-S_ratio)*C_D)
        W.append(V*S_ratio*S_D+V*(1-S_ratio)*C_D)
        D.append((V*S_ratio*S_D+V*(1-S_ratio)*C_D)/V)
F_S_W=sum(S_W)
F_C_W=sum(C_W)
F_W=sum(W)
################################ other walls ##########################################
for w in file.by_type('IfcWall'):
    if ("Exterior" in w.ObjectType):
        #find steel ratio and concrete density of the element
        cont = True
        i=1
        while cont:
            i+=1
            if inputs.cell(i,1).value == w.Name[11:19]+w.Name[36:]:
                S_ratio = inputs.cell(i,2).value
                C_D = inputs.cell(i,3).value
                cont = False
        if  (S_ratio < 0)|(S_ratio>1)|(C_D<0):
            print("\nERROR:  : input out of range")
        #find volume of the element
        for definition in w.IsDefinedBy:    
            ## To support IFC2X3, we need to filter our results.
            if definition.is_a('IfcRelDefinesByProperties'):
                property_set = definition.RelatingPropertyDefinition
                if property_set.Name == "PSet_Revit_Dimensions":
                    for property in property_set.HasProperties:
                        if property.Name=="Volume":
                            V = float(str(property[2])[17:len(str(property[2]))-1])
        W_V=W_V+V
        NAME.append(w.Name[11:19]+w.Name[36:])
        S_V.append(V*S_ratio)
        S_W.append(V*S_ratio*S_D)
        C_V.append(V*(1-S_ratio))
        C_W.append(V*(1-S_ratio)*C_D)
        W.append(V*S_ratio*S_D+V*(1-S_ratio)*C_D)
        D.append((V*S_ratio*S_D+V*(1-S_ratio)*C_D)/V)
    if ("Party" in w.ObjectType):
        #find steel ratio and concrete density of the element
        cont = True
        i=1
        while cont:
            i+=1
            if inputs.cell(i,1).value == w.Name[11:21]+w.Name[58:]:
                S_ratio = inputs.cell(i,2).value
                C_D = inputs.cell(i,3).value
                cont = False
        if  (S_ratio < 0)|(S_ratio>1)|(C_D<0):
            print("\nERROR:input out of range")
        #find volume of the element
        for definition in w.IsDefinedBy:    
            ## To support IFC2X3, we need to filter our results.
            if definition.is_a('IfcRelDefinesByProperties'):
                property_set = definition.RelatingPropertyDefinition
                if property_set.Name == "PSet_Revit_Dimensions":
                    for property in property_set.HasProperties:
                        if property.Name=="Volume":
                            V = float(str(property[2])[17:len(str(property[2]))-1])
        W_V=W_V+V
        NAME.append(w.Name[11:21]+w.Name[58:])
        S_V.append(V*S_ratio)
        S_W.append(V*S_ratio*S_D)
        C_V.append(V*(1-S_ratio))
        C_W.append(V*(1-S_ratio)*C_D)
        W.append(V*S_ratio*S_D+V*(1-S_ratio)*C_D)
        D.append((V*S_ratio*S_D+V*(1-S_ratio)*C_D)/V)
W_S_W=sum(S_W)-F_S_W
W_C_W=sum(C_W)-F_C_W
W_W=sum(W)-F_W
################## create the excel file with the elements sheet ######################
df = pd.DataFrame.from_dict({"ID":NAME,"S_Volume(m3)":S_V,"S_Weight(kg)":S_W,"C_Volume(m3)":C_V,"C_Weight(kg)":C_W,"Weight(kg)":W,"Density(kg/m3)":D},)
df.to_excel(r"C:\Users\loics\Weight and Density Values of Walls and Foundations\output\StructuralWallsWeight.xlsx",sheet_name="elements",float_format="%.3f")  
wb = openpyxl.load_workbook(r"C:\Users\loics\Weight and Density Values of Walls and Foundations\output\StructuralWallsWeight.xlsx")
elements = wb["elements"]

############################ create the global values sheet ###########################
Global = wb.create_sheet("global values")
Global.cell(1,1).value="Combined Foundations volume(m3) ="
Global.cell(2,1).value="Combined Foundations weight(kg) ="
Global.cell(3,1).value="Combined Foundations steel weight(kg) ="
Global.cell(4,1).value="Combined Foundations concrete weight(kg) ="
Global.cell(1,2).value=F_V
Global.cell(2,2).value=F_W
Global.cell(3,2).value=F_S_W
Global.cell(4,2).value=F_C_W
Global.cell(5,1).value="Combined Walls volume(m3) ="
Global.cell(6,1).value="Combined Walls weight(kg) ="
Global.cell(7,1).value="Combined Walls steel weight(kg) ="
Global.cell(8,1).value="Combined Walls concrete weight(kg) ="
Global.cell(5,2).value=W_V
Global.cell(6,2).value=W_W
Global.cell(7,2).value=W_S_W
Global.cell(8,2).value=W_C_W
############################# make it readible ########################################
Global.column_dimensions['A'].width = 37
elements.column_dimensions['A'].width = 1
elements.column_dimensions['B'].width = 16
elements.column_dimensions['C'].width = 15
elements.column_dimensions['D'].width = 15
elements.column_dimensions['E'].width = 15
elements.column_dimensions['F'].width = 15
elements.column_dimensions['G'].width = 15
elements.column_dimensions['H'].width = 15
Global.cell(1,1).fill = openpyxl.styles.fills.PatternFill(patternType='solid', fgColor=openpyxl.styles.colors.Color(rgb='B3D9FF'))
for r in range(2,9):
    Global.cell(r,1).fill = openpyxl.styles.fills.PatternFill(patternType='solid', fgColor=openpyxl.styles.colors.Color(rgb='B3D9FF'))
    elements.cell(1,r).fill = openpyxl.styles.fills.PatternFill(patternType='solid', fgColor=openpyxl.styles.colors.Color(rgb='B3D9FF'))
    for s in range(2,len(NAME)+2):
        elements.cell(s,r).alignment = openpyxl.styles.Alignment(horizontal='center')
        elements.cell(s,2).fill = openpyxl.styles.fills.PatternFill(patternType='solid', fgColor=openpyxl.styles.colors.Color(rgb='B3D9FF'))
wb.save(r"C:\Users\loics\Weight and Density Values of Walls and Foundations\output\StructuralWallsWeight.xlsx")




                        
        




